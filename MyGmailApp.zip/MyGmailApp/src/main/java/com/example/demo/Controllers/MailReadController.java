package com.example.demo.Controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets.Details;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.gmail.GmailScopes;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.gmail.model.MessagePartHeader;

@RestController
public class MailReadController {
	
	private static final String APPLICATION_NAME = "MyGmailApp";
	private static HttpTransport httpTransport;
	private static	 final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static com.google.api.services.gmail.Gmail client;
	
	private String clientId="435804715742-0e75u4e9bu385gttsqsud5psr5i5214o.apps.googleusercontent.com";
	private String clientSecret="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";
	private String redirectUri="http://localhost:8089/login/gmailCallback";
	
	GoogleClientSecrets clientSecrets;
	GoogleAuthorizationCodeFlow flow;
	Credential credential;
	
	
	@RequestMapping(value = "/login/gmail", method = RequestMethod.GET)
	public RedirectView googleConnectionStatus(HttpServletRequest request) throws Exception {
		return new RedirectView(authorize());
	}
	
	@RequestMapping(value = "/login/gmailCallback", method = RequestMethod.GET, params = "code")
	public ResponseEntity<String> oauth2Callback(@RequestParam(value = "code") String code) {
		System.out.println("code is"+code);
		System.out.println("hum callback function kai andar aa chuke haii");

		// System.out.println("code->" + code + " userId->" + userId + "
		// query->" + query);

		JSONObject json = new JSONObject();
		JSONArray arr = new JSONArray();

		// String message;
		try {
			String userId = "me";
			TokenResponse response = flow.newTokenRequest(code).setRedirectUri(redirectUri).execute();
			System.out.println("response is"+response);
			credential = flow.createAndStoreCredential(response, "userID");

			client = new com.google.api.services.gmail.Gmail.Builder(httpTransport, JSON_FACTORY, credential)
					.setApplicationName(APPLICATION_NAME).build();
			      
			String date1="2021/07/11" ;
			String date2="2021/11/01";
			String query = "in:inbox " + " subject:(summary OR added OR invested OR deposit OR order)" + " ((paid OR rs OR money OR credit OR debit OR inr OR wallet OR ₹) "
					+ "+AND has:attachment OR has:drive AND -codechef AND -edureka)"+ " after:" + date1 + " before:"+date2;
			
			String query1 = "in:inbox subject:(summary OR added OR invested OR deposit OR order)";
			
			String query2 = "in:inbox"+" after:" + date1 + " before:"+date2;
			System.out.println("clienti is "+client);
			
			ListMessagesResponse MsgResponse = client.users().messages().list(userId).setQ(query2).execute();

			List<Message> messages = new ArrayList<>();

			System.out.println("message length:" + MsgResponse.getMessages().size());

			for (Message msg : MsgResponse.getMessages()) {

				messages.add(msg);
				System.out.println("message id"+msg.getId());

				Message message = client.users().messages().get(userId, msg.getId()).execute();
				System.out.println("snippet :" + message.getSnippet());
				
				List<MessagePartHeader> headers = new ArrayList<>();
				headers=message.getPayload().getHeaders();
				//System.out.println("headers is "+headers.size());
				for(int i=0;i<headers.size();i++) {
					if(headers.get(i).getName().toLowerCase().equalsIgnoreCase("date")) {
						System.out.println(headers.get(i).getValue());
					}
					
				}
			//System.out.println(headers.get(19));

				/*
				 * if (MsgResponse.getNextPageToken() != null) { String
				 * pageToken = MsgResponse.getNextPageToken(); MsgResponse =
				 * client.users().messages().list(userId).setQ(query).
				 * setPageToken(pageToken).execute(); } else { break; }
				 */
			}
			


			json.put("response", arr);

			for (Message msg : messages) {

				System.out.println("msg: " + msg.toPrettyString());
			}

		} catch (Exception e) {

			System.out.println("exception cached ");
			e.printStackTrace();
		}

		return new ResponseEntity<>(json.toString(), HttpStatus.OK);
	}
	
	
	
	
	private String authorize() throws Exception {
		System.out.println("hum authorize kai andar haii");
		AuthorizationCodeRequestUrl authorizationUrl;
		if (flow == null) {
			System.out.println("hum authorize kai if blog jaga flow null aata hai waha hai");
			Details web = new Details();
			web.setClientId(clientId);
			web.setClientSecret(clientSecret);
			clientSecrets = new GoogleClientSecrets().setWeb(web);
			httpTransport = GoogleNetHttpTransport.newTrustedTransport();
			flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, JSON_FACTORY, clientSecrets,
					Collections.singleton(GmailScopes.GMAIL_READONLY)).build();
		}
		authorizationUrl = flow.newAuthorizationUrl().setRedirectUri(redirectUri);

		System.out.println("gamil authorizationUrl ->" + authorizationUrl);
		return authorizationUrl.build();
	}
	

}
